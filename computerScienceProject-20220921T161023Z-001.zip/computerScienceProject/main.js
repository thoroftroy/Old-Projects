//cosole.logs the start of the program
console.log("Program Start");
//creates a popup window at the start of the program
//alert("Here is my collection of js games I have created")


