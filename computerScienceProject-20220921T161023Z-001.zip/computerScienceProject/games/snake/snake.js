!function(t) {
    var e = {};
    function i(s) {
        if (e[s])
            return e[s].exports;
        var r = e[s] = {
            i: s,
            l: !1,
            exports: {}
        };
        return t[s].call(r.exports, r, r.exports, i),
        r.l = !0,
        r.exports
    }
    i.m = t,
    i.c = e,
    i.d = function(t, e, s) {
        i.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: s
        })
    }
    ,
    i.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }),
        Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }
    ,
    i.t = function(t, e) {
        if (1 & e && (t = i(t)),
        8 & e)
            return t;
        if (4 & e && "object" == typeof t && t && t.__esModule)
            return t;
        var s = Object.create(null);
        if (i.r(s),
        Object.defineProperty(s, "default", {
            enumerable: !0,
            value: t
        }),
        2 & e && "string" != typeof t)
            for (var r in t)
                i.d(s, r, function(e) {
                    return t[e]
                }
                .bind(null, r));
        return s
    }
    ,
    i.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        }
        : function() {
            return t
        }
        ;
        return i.d(e, "a", e),
        e
    }
    ,
    i.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }
    ,
    i.p = "",
    i(i.s = 0)
}([function(t, e, i) {
    "use strict";
    i.r(e);
    class s {
        constructor(t, e, i) {
            this.x = t,
            this.y = e,
            this.dir = i
        }
        collides(t) {
            return this.xx == t.xx && this.yy == t.yy
        }
        get xx() {
            return Math.round(this.x / scl)
        }
        get yy() {
            return Math.round(this.y / scl)
        }
    }
    class r {
        constructor(t, e, i, r) {
            this.x = t,
            this.y = e,
            this.color = r,
            this.body = [],
            this.dir = {
                x: 0,
                y: 0
            },
            this.newDir = {
                x: 0,
                y: 0
            },
            this.greenFace = new Image,
            this.greenFace.src = "images/head.png",
            this.redFace = new Image,
            this.redFace.src = "images/redHead.png",
            this.face = this.greenFace;
            for (var n = 0; n < i; n++)
                this.body.push(new s((this.x - n) * scl,this.y * scl,{
                    x: 1,
                    y: 0
                }))
        }
        update() {
            if (!this.isDead && ((keys.a || keys.arrowleft) && 0 == this.dir.x && (this.newDir.x = -1,
            this.newDir.y = 0),
            (keys.d || keys.arrowright) && 0 == this.dir.x && (this.newDir.x = 1,
            this.newDir.y = 0),
            (keys.s || keys.arrowdown) && 0 == this.dir.y && (this.newDir.y = 1,
            this.newDir.x = 0),
            (keys.w || keys.arrowup) && 0 == this.dir.y && (this.newDir.y = -1,
            this.newDir.x = 0),
            0 != this.dir.x || 0 != this.dir.y || 0 != this.newDir.x || 0 != this.newDir.y)) {
                if (0 == (this.head.x / scl).toFixed(1).substr(-1) && 0 == (this.head.y / scl).toFixed(1).substr(-1)) {
                    if (this.checkDeath() && !this.isDead)
                        return this.die();
                    this.body[1].xx == this.head.xx + this.newDir.x && this.body[1].yy == this.head.yy + this.newDir.y || (this.dir.x = this.newDir.x,
                    this.dir.y = this.newDir.y,
                    this.head.dir.x = this.dir.x,
                    this.head.dir.y = this.dir.y);
                    for (let t = this.length - 1; t > 0; t--)
                        this.body[t].dir.x = (this.body[t - 1].x - this.body[t].x) / scl,
                        this.body[t].dir.y = (this.body[t - 1].y - this.body[t].y) / scl
                }
                this.body.forEach(t=>{
                    t.x += t.dir.x * speed,
                    t.y += t.dir.y * speed
                }
                )
            }
        }
        draw() {
            this.body.forEach(t=>{
                ctx.fillStyle = this.color,
                ctx.fillRect(t.x, t.y, scl, scl),
                keys.shift && (ctx.strokeStyle = "red",
                ctx.strokeRect(t.xx * scl, t.yy * scl, scl, scl))
            }
            ),
            ctx.drawImage(this.face, this.head.x, this.head.y, scl, scl)
        }
        appendNew() {
            let t = this.tail;
            this.body.push(new s(t.x,t.y,{
                x: 0,
                y: 0
            }))
        }
        checkDeath() {
            if (this.head.xx >= tileCount || this.head.yy >= tileCount || this.head.xx < 0 || this.head.yy < 0)
                return !0;
            for (let t = 1; t < this.length; t++)
                if (this.head.collides(this.body[t]))
                    return !0;
            return !1
        }
        die() {
            this.isDead = !0;
            let t = this.color;
            this.color = "red",
            this.face = this.redFace,
            setTimeout(()=>{
                this.color = t,
                this.face = this.greenFace,
                setTimeout(()=>{
                    this.color = "red",
                    this.face = this.redFace
                }
                , 200)
            }
            , 200)
        }
        get length() {
            return this.body.length
        }
        get head() {
            return this.body[0]
        }
        get tail() {
            return this.body[this.body.length - 1]
        }
        get xx() {
            return this.head.xx
        }
        get yy() {
            return this.head.yy
        }
    }
    class n {
        constructor() {
            return new Proxy(this,this)
        }
        get(t, e) {
            try {
                return JSON.parse(localStorage.getItem(e))
            } catch (t) {
                return console.warn("Unable to load value from localstorage"),
                null
            }
        }
        set(t, e, i) {
            try {
                return localStorage.setItem(e, JSON.stringify(i)),
                !0
            } catch (t) {
                return console.warn("Unable to store value to localstorage"),
                !1
            }
        }
    }
    class o {
        constructor(t, e, i) {
            this.xx = t,
            this.yy = e,
            this.padding = i,
            this.p = i,
            this.color = "red"
        }
        generateNew() {
            this.xx = Math.round(Math.random() * (tileCount - 1)),
            this.yy = Math.round(Math.random() * (tileCount - 1));
            let t = !1;
            snake.body.forEach(e=>{
                e.xx == this.xx && this.yy == e.yy && (t = !0)
            }
            ),
            t ? this.generateNew() : this.p = scl / 2
        }
        draw() {
            ctx.fillStyle = this.color,
            ctx.fillRect(this.x + this.p, this.y + this.p, scl - 2 * this.p, scl - 2 * this.p),
            this.p > this.padding && this.p--
        }
        get x() {
            return this.xx * scl
        }
        get y() {
            return this.yy * scl
        }
    }
    let h, a, d, c = 0;
    window.tileCount = 11,
    window.speed = 7;
    let l = !1;
    function y() {
        l || (ctx.fillStyle = "black",
        ctx.fillRect(0, 0, canvas.width, canvas.height),
        h.draw(),
        snake.update(),
        snake.draw(),
        ctx.font = 1.5 * scl + "px Arial",
        ctx.fillStyle = "#fff",
        ctx.fillText(c, canvas.width / 2 - ctx.measureText(c).width / 2, 2.5 * scl),
        ctx.font = .5 * scl + "px Arial",
        ctx.fillStyle = "#fff",
        ctx.fillText("High score: " + d, canvas.width / 2 - ctx.measureText("High score: " + d).width / 2, 3.5 * scl),
        snake.head.collides(h) && (h.generateNew(),
        snake.appendNew(),
        c++),
        c > d && (d = c,
        a._hscore = d))
    }
    window.onload = function() {
        window.canvas = document.querySelector("#canvas"),
        window.ctx = canvas.getContext("2d"),
        a = new n,
        window.scl = canvas.width / tileCount,
        h = new o(6,Math.floor(tileCount / 2),5),
        window.snake = new r(4,Math.floor(tileCount / 2),3,"rgb(50, 255, 50)"),
        d = a._hscore || 0,
        setInterval(y, 1e3 / 90)
    }
    ,
    window.keys = {},
    window.mouse = {
        x: 0,
        y: 0,
        isDown: !1
    };
    document.addEventListener("keydown", t=>{
        snake.isDead && window.location.reload(),
        keys[t.key.toLowerCase()] = !0
    }
    ),
    document.addEventListener("keyup", t=>keys[t.key.toLowerCase()] = !1),
    document.addEventListener("mousedown", t=>mouse.isDown = !0),
    document.addEventListener("mouseup", t=>mouse.isDown = !1),
    document.addEventListener("mousemove", t=>{
        let e = canvas.getBoundingClientRect();
        [mouse.x,mouse.y] = [t.clientX - e.left, t.clientY - e.top]
    }
    )
}
]);
